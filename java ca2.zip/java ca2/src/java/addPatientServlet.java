
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addPatientServlet")
public class addPatientServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String patientId = request.getParameter("patientId");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String gender = request.getParameter("gender");
        String phoneNumber = request.getParameter("phoneNumber");
        String address = request.getParameter("address");

        PrintWriter out = response.getWriter();
        
        Connection conn = null;
        PreparedStatement psmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospitalsystem", "root", "root75");

            String query = "INSERT INTO patients (patient_id, first_name, last_name, gender, phone_number, address) VALUES (?, ?, ?, ?, ?, ?)";
            psmt = conn.prepareStatement(query);
            psmt.setString(1, patientId);
            psmt.setString(2, firstName);
            psmt.setString(3, lastName);
            psmt.setString(4, gender);
            psmt.setString(5, phoneNumber);
            psmt.setString(6, address);

            int result = psmt.executeUpdate();
            if (result > 0) {
                response.sendRedirect("doctorDashboard.jsp");
            } else {
                response.getWriter().println("Error adding patient.");
            }
        } catch (IOException | ClassNotFoundException | SQLException e) {
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try {
                if (psmt != null) psmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                out.println("Eror :"+e);
            }
        }
    }
}
